package utils;

public class databaseAcess {

	public static String USER = "root";
	public static String PASS = "qazwsx123";
}
